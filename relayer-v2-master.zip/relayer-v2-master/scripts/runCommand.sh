
#!/bin/bash

# Simple script that simply runs a command input as an environment variable.
$COMMAND