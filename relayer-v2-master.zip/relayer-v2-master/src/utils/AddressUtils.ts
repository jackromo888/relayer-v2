import { BigNumber } from ".";

export function compareAddresses(addressA: string, addressB: string) {
  // Convert address strings to BigNumbers and then sort numerical value of the BigNumber, which sorts the addresses
  // effectively by their hex value.
  const bnAddressA = BigNumber.from(addressA);
  const bnAddressB = BigNumber.from(addressB);
  if (bnAddressA.gt(bnAddressB)) return 1;
  else if (bnAddressA.lt(bnAddressB)) return -1;
  else return 0;
}
