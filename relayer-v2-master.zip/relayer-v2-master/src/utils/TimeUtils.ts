export function getCurrentTime() {
  return Math.round(Date.now().valueOf() / 1000);
}
