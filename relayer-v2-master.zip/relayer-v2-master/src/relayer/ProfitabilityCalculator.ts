// todo: build out a module that considers the price of each asset and works out if relaying the given token would be profitable.
